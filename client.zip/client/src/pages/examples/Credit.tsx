import Credit from '../Credit';

export default function CreditExample() {
  return <Credit />;
}
