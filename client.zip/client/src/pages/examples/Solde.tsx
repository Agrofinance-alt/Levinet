import Solde from '../Solde';

export default function SoldeExample() {
  return <Solde />;
}
