import Performance from '../Performance';

export default function PerformanceExample() {
  return <Performance />;
}
