import AddCartePointage from '../AddCartePointage';

export default function AddCartePointageExample() {
  return <AddCartePointage />;
}
