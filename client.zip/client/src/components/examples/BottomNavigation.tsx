import BottomNavigation from '../BottomNavigation';

export default function BottomNavigationExample() {
  return <BottomNavigation />;
}
