import Epargne from '../Epargne';

export default function EpargneExample() {
  return <Epargne />;
}
