import Profile from '../Profile';

export default function ProfileExample() {
  return <Profile />;
}
