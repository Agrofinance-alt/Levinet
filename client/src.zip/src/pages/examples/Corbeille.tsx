import Corbeille from '../Corbeille';

export default function CorbeilleExample() {
  return <Corbeille />;
}
