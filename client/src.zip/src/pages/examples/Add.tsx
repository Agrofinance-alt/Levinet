import Add from '../Add';

export default function AddExample() {
  return <Add />;
}
