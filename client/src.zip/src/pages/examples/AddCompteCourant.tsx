import AddCompteCourant from '../AddCompteCourant';

export default function AddCompteCourantExample() {
  return <AddCompteCourant />;
}
