import AddCredit from '../AddCredit';

export default function AddCreditExample() {
  return <AddCredit />;
}
