import Contencieux from '../Contencieux';

export default function ContencieuxExample() {
  return <Contencieux />;
}
